
<div class="footer">Made with <i class="wdv-icon wdv-icon-heart" aria-hidden="true"></i> by WPMU DEV</div>

<script type="text/html" id="ss-modal-template">
	<div class="ss-modal hidden">
		<div id="" class="dev-box modal-box">
			<div class="wpmud-box-title buttons">
				<h3></h3>
				<div class="ss-icon-close close"></div>
			</div>

			<div class="wpmud-box-content"></div>
		</div>
	</div>
</script>