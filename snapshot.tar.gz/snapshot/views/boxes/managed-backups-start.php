<div class="wpmud-box-title badge">
    <h3>Managed Backups</h3><span class="badge">Premium</span>
</div><!-- end wpmud-box-title -->

<div class="wpmud-box-content">
    <div class="row">
        <p><img class="hero-circle"><br>Back up and restore your website, including WordPress core files, on WPMU DEV's secure cloud servers.</p>
        <a href="http://snapshot.wpmudev.dev/wp-admin/admin.php?page=wphb&amp;run=true&amp;type=performance&amp;_wpnonce=0360bdece0#wphb-box-dashboard-performance-running-test" class="button button-blue">Backup my Site</a>

    </div>
</div><!-- end wpmud-box-content -->